<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="styles.css">

  </head>
  <body>
    <div class="cap">
      <div class="titol">
        <b>carsandfilms</b>
      </div>
      <div class="anim">

      </div>
    </div>

    <div class="cos">
      <div class="cos1">
      <div class="quadrat1">
        <div>
          <img src="carsandfilms/img/small/small_pulp.jpg">
          <h4>Pulp Fiction</h4>
        </div>
      </div>
      <div class="quadrat1">
        <div>
          <img src="carsandfilms/img/small/small_taxi.jpg">
          <h4>Taxi Driver</h4>
        </div>
      </div>
      <div class="quadrat1">
        <div>
          <img src="carsandfilms/img/small/small_bond.jpg">
          <h4>Goldfinger</h4>
        </div>
      </div>
    </div>

    <div class="cos2">
      <div class="quadrat1">
        <div>
          <img src="carsandfilms/img/small/small_ghost.jpg">
          <h4>Ghost Busters</h4>
        </div>
      </div>
      <div class="quadrat1">
        <div>
          <img src="carsandfilms/img/small/small_bean.jpg">
          <h4>Mr. Bean</h4>
        </div>
      </div>
      <div class="quadrat1">
        <div>
          <img src="carsandfilms/img/small/small_back.jpg">
          <h4>Back to the Future</h4>
        </div>
      </div>
    </div>

    <div class="cos3">
      <div class="quadrat1">
        <div>
          <img src="carsandfilms/img/small/small_rider.jpg">
          <h4>Knight Rider</h4>
        </div>
      </div>
      <div class="quadrat1">
        <div>
          <img src="carsandfilms/img/small/small_team.jpg">
          <h4>The A-Team</h4>
        </div>
      </div>
      <div class="quadrat1">
        <div>
          <img src="carsandfilms/img/small/small_break.jpg">
          <h4>Breaking Bad</h4>
        </div>
      </div>
    </div>
    </div>

  <div class="peu">
    <img src="carsandfilms/img/logo_carsandfilms.png">
  </div>
  </body>
</html>
